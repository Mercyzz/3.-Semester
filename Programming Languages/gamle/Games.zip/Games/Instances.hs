{-# LANGUAGE TypeFamilies,FlexibleContexts #-}
module Instances where
import Game
import Data.List

{- Ex. 1 -}

type Goal = Int
type MaxAdd = Int
data AddingGame = AddingGame Goal MaxAdd deriving Show

instance (Game AddingGame) where
  type Move AddingGame = Int
  type GameState AddingGame = Int

  startState    g       = undefined
  value         g p s   = undefined
  moves         g p s   = undefined
  move          g p s m = undefined
  showGame      g s     = undefined


{- Ex. 2 -}

leftmostGame :: Game g => g -> Player -> GameState g -> [GameState g]  
leftmostGame = undefined
rightmostGame :: Game g => g -> Player -> GameState g -> [GameState g]
rightmostGame = undefined

{- Ex. 3 -}

data Game1D = Game1D Int

data Direction = L | R deriving Show
type Position = Int
data Move1D = Computer Position Value | Human Direction deriving Show

instance (Game Game1D) where
  type Move Game1D = Move1D
  type GameState Game1D = [Int]

  startState    g       = undefined
  value         g p s   = undefined
  moves         g p s   = undefined
  move          g p s m = undefined
  showGame      g s     = undefined
