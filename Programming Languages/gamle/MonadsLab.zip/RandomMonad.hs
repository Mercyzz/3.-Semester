module RandomMonad where
import System.Random  
import Control.Monad.State  


die6 :: StdGen -> (Int,StdGen)
die6 g = randomR (1,6) g

twoDie :: StdGen -> (Int, StdGen)
twoDie g = let  (d1,g')   = die6 g
                (d2,g'')  = die6 g'
           in   (d1+d2, g'')

test :: IO (Int,StdGen)              
test = do g <- newStdGen
          return (twoDie g)
          
          

-- state    :: (s -> (a, s))    ->  State s a
-- runState :: State s a -> s   ->  (a, s)


die6' :: State StdGen Int
die6' = undefined

twoDie' :: State StdGen Int
twoDie' = undefined
    
test' :: IO (Int,StdGen)
test' = do  g <- newStdGen
            return (runState twoDie' g)