module ExprMonad where

data Expr a = Var a | Add (Expr a) (Expr a) deriving Show

instance Monad Expr where
    return x         = undefined
    (Var a)   >>= f  = undefined
    (Add x y) >>= f  = undefined

replace :: Eq a => [(a,b)] -> Expr a -> Expr (Maybe b)
replace = undefined

convert :: Expr (Maybe a) -> Maybe (Expr a)
convert = undefined